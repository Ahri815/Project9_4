package com.example.project9_4;
import android.graphics.Canvas;
import android.graphics.Paint;
public abstract class Shape {
    float startX, startY, stopX, stopY;
    Paint paint;
    public Shape(float startX, float startY, float stopX, float stopY) {
        this.startX = startX;
        this.startY = startY;
        this.stopX = stopX;
        this.stopY = stopY;
        paint = new Paint();
        paint.setStrokeWidth(5);
    }
    public abstract void draw(Canvas canvas);
}