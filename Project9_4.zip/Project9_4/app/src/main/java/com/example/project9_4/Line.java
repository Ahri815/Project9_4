package com.example.project9_4;
import android.graphics.Canvas;
public class Line extends Shape {
    public Line(float startX, float startY, float stopX, float stopY) {
        super(startX, startY, stopX, stopY);
    }
    @Override
    public void draw(Canvas canvas) {
        canvas.drawLine(startX, startY, stopX, stopY, paint);
    }
}