package com.example.project9_4;
import android.content.Context;
import android.graphics.Canvas;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
public class MyView extends View {
    ArrayList<Shape> shapeList = new ArrayList<>();
    Shape currentShape = null;
    int shapeType = 1; // 1: Line, 2: Circle, 3: Rect
    float startX, startY, stopX, stopY;
    public MyView(Context context) {
        super(context);
    }
    public void setShapeType(int type) {
        shapeType = type;
    }
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        for (Shape s : shapeList) {
            s.draw(canvas);
        }
    }
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                startX = event.getX();
                startY = event.getY();
                break;
            case MotionEvent.ACTION_UP:
                stopX = event.getX();
                stopY = event.getY();
                switch (shapeType) {
                    case 1: currentShape = new Line(startX, startY, stopX, stopY); break;
                    case 2: currentShape = new Circle(startX, startY, stopX, stopY); break;
                    case 3: currentShape = new Rect(startX, startY, stopX, stopY); break;
                }
                shapeList.add(currentShape);
                invalidate();
                break;
        }
        return true;
    }
}