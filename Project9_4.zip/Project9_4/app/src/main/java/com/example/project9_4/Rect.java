package com.example.project9_4;
import android.graphics.Canvas;
import android.graphics.RectF;
public class Rect extends Shape {
    public Rect(float startX, float startY, float stopX, float stopY) {
        super(startX, startY, stopX, stopY);
    }
    @Override
    public void draw(Canvas canvas) {
        canvas.drawRect(new RectF(startX, startY, stopX, stopY), paint);
    }
}