package com.example.project9_4;
import android.graphics.Canvas;
public class Circle extends Shape {
    public Circle(float startX, float startY, float stopX, float stopY) {
        super(startX, startY, stopX, stopY);
    }
    @Override
    public void draw(Canvas canvas) {
        float radius = (float) Math.hypot(stopX - startX, stopY - startY);
        canvas.drawCircle(startX, startY, radius, paint);
    }
}